STRING CIRCLE — WORLD COUNTRY BATTLE
Ready-to-publish package
========================

WHAT IS IN HERE
---------------
world-country-battle/            <- the complete repository
  index.html                     the whole game (HTML + CSS + JS)
  dist/StringCircle-WorldCountryBattle-1.0.0.apk   prebuilt, signed APK
  android/                       Android WebView wrapper project
  .github/workflows/android.yml  builds a fresh APK on every v* tag
  README.md  CHANGELOG.md  SKILL.md
  docs/icon.png

HOW TO PUBLISH (browser only, no git needed)
--------------------------------------------
1. Unzip this archive. You get one folder: world-country-battle
2. Open your empty repository:
   https://github.com/R4T-Hackz/world-country-battle
3. Click "Add file" -> "Upload files"
4. Drag the whole "world-country-battle" FOLDER into the page
   (Chrome or Edge on a laptop; it keeps all sub-folders)
5. Scroll down, click "Commit changes"
6. Go to "Releases" (right sidebar) -> "Draft a new release"
   - Choose a tag: type  v1.0.0  -> "Create new tag"
   - Release title: String Circle — World Country Battle v1.0.0
   - Drag dist/StringCircle-WorldCountryBattle-1.0.0.apk into the
     "Attach binaries" box
   - Click "Publish release"

Done. The APK is now downloadable at:
https://github.com/R4T-Hackz/world-country-battle/releases/latest

IF DRAGGING A FOLDER DOES NOT WORK
----------------------------------
Use the command line instead (from inside the unzipped folder):

  cd world-country-battle
  git remote add origin https://github.com/R4T-Hackz/world-country-battle.git
  git push -u origin main
  git tag v1.0.0
  git push origin v1.0.0

The .github workflow then builds the APK and attaches it to the
release automatically.

NOTE ON AUTOMATION
------------------
The connected GitHub integration is read-only for this account
(every write returns 403 "Resource not accessible by integration"),
so the files have to be uploaded from your side once. After that,
every tag push builds a new APK automatically.
