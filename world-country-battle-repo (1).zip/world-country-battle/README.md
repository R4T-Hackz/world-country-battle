# 🎯 String Circle — World Country Battle

A fast, physics-driven "last country standing" battle game. Every country is a bouncing ball inside a circular arena, and every ball owns a fan of strings. When a rival ball touches a string, the string is cut. The last country with strings left on the rim wins.

Built as a single self-contained HTML file, wrapped into an installable Android APK.

[![Build Android APK](https://github.com/R4T-Hackz/world-country-battle/actions/workflows/android.yml/badge.svg)](https://github.com/R4T-Hackz/world-country-battle/actions/workflows/android.yml)
![Platform](https://img.shields.io/badge/platform-Android%205.0%2B-3ddc84)
![Size](https://img.shields.io/badge/APK-~1%20MB-blue)
![No ads](https://img.shields.io/badge/ads-none-brightgreen)

---

## ⬇️ Download the APK

**Latest release:** [github.com/R4T-Hackz/world-country-battle/releases/latest](https://github.com/R4T-Hackz/world-country-battle/releases/latest)

| File | Android | Size |
| --- | --- | --- |
| `StringCircle-WorldCountryBattle-1.0.0.apk` | 5.0 (Lollipop) and above | ~1 MB |

Direct link (latest release):
`https://github.com/R4T-Hackz/world-country-battle/releases/latest/download/StringCircle-WorldCountryBattle-1.0.0.apk`

A prebuilt, debug-signed copy also ships in the repository at
[`dist/StringCircle-WorldCountryBattle-1.0.0.apk`](dist/StringCircle-WorldCountryBattle-1.0.0.apk),
so you can download it even before the first CI release finishes.

### How to install

1. Tap the `.apk` link on your phone and download it.
2. Open the downloaded file from your notification shade or Files app.
3. Android will warn that the app is from an unknown source — tap **Settings → Allow from this source**.
4. Tap **Install**, then **Open**.

The build is debug-signed (standard for open-source sideload builds), so Play Protect may show a "scan" prompt. Choose **Install anyway** if you trust the source — the source is right here in this repository.

> Prefer not to install anything? You can also play it in the browser at
> `https://R4T-Hackz.github.io/string-circle/` once GitHub Pages is enabled in
> Settings → Pages (branch `main`, folder `/`).

---

## 🕹️ How to play

1. Pick **2 to 5 countries** — 195 sovereign countries are available, each with its real flag.
2. Choose **strings per country** (1–80, default 50).
3. Hit **Start** and watch the balls bounce, collide and cut each other's strings.
4. A country is eliminated the moment its last string is cut.
5. The last country with strings remaining takes the crown.

Battles typically resolve in 25–45 seconds.

## ✨ Features

- **Real physics** — gravity, elastic ball-to-ball collisions, circle-wall bounces with anti-loop jitter, and speed regulation so balls never stall. Simulated in 3 sub-steps per frame for stable collisions.
- **195 countries** with live flag images (flagcdn) and ISO 3166-1 alpha-2 codes.
- **Country picker with search** — type "India", "Japan", "Brazil" and pick any nation for any slot.
- **Randomise** — shuffle a fresh set of countries in one tap.
- **Adjustable chaos** — 1–80 strings per country, 2–5 countries.
- **Speed control** — 0.75×, 1.0×, 1.5×, 2.0×.
- **Synthesised sound** — snap, bounce, elimination and victory sounds generated with the Web Audio API. No audio files, no downloads.
- **Clean / record mode** — hides all UI chrome so you can screen-record a clean battle.
- **Winner overlay** with flag, remaining strings and elapsed time, plus instant Replay.
- **Zero tracking, zero ads, no network calls except flags and fonts.**

## 🎛️ Controls

| Control | Action |
| --- | --- |
| **Countries** | Open the setup modal (count, country per slot, strings) |
| ▶ / ⏸ | Start, pause, resume, replay |
| ↺ | Restart the current battle |
| 🎲 | Randomise the countries |
| `1.0x` | Cycle simulation speed |
| 🔊 / 🔇 | Mute or unmute |
| 👁 | Clean / record mode (hide UI) |

## 📱 Android app

The APK is a thin native shell: an `Activity` hosting a full-screen `WebView` that loads the game from `android/app/src/main/assets/index.html`. No third-party libraries, no AndroidX, no analytics — it is the same HTML file that ships in the repository root.

- Immersive full-screen, portrait-locked, screen kept awake during play.
- Internet permission is used only for flag images and Google Fonts.
- Built by GitHub Actions on every push to `main`, and attached to a GitHub Release on every `v*` tag.

## 🛠️ Build it yourself

### Browser

```bash
# just open it
open index.html      # macOS
xdg-open index.html  # Linux
```

### APK

Requires JDK 17 and the Android SDK (compileSdk 34).

```bash
cp index.html android/app/src/main/assets/index.html
cd android
gradle assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
```

Or let CI do it: push a tag and the workflow publishes the APK to a release.

```bash
git tag v1.0.1 && git push origin v1.0.1
```

## 📁 Repository layout

```
.
├── index.html                  # the entire game (HTML + CSS + JS)
├── android/                    # WebView wrapper project
│   ├── app/build.gradle
│   └── app/src/main/
│       ├── AndroidManifest.xml
│       ├── java/.../MainActivity.java
│       ├── assets/index.html   # synced from repo root by CI
│       └── res/                # icons, theme, strings
├── .github/workflows/android.yml
├── SKILL.md                    # game spec / agent skill document
├── CHANGELOG.md
└── README.md
```

## ⚙️ Technical notes

- Rendering: single `<canvas>` 2D context, DPR-aware, re-scaled on resize with proportional ball repositioning.
- Loop: `requestAnimationFrame` with a clamped `dt` (max 40 ms) so tab-switches don't teleport the simulation.
- String cutting uses point-to-segment distance with a small margin near the owner's centre, plus a per-cut cooldown so one pass doesn't wipe a whole fan.
- Styling uses Tailwind via CDN; typography uses Inter from Google Fonts. Both are cosmetic — offline, the game still runs with system fonts and a slightly different look.

## 📄 License

No license file is included yet. Until one is added, all rights are reserved by the author. Open an issue if you want to reuse the code and we can pick one (MIT is the usual choice for something like this).

## 🙏 Credits

- Flags: [flagcdn.com](https://flagcdn.com)
- Fonts: [Inter](https://fonts.google.com/specimen/Inter) via Google Fonts
- Styling: [Tailwind CSS](https://tailwindcss.com)
