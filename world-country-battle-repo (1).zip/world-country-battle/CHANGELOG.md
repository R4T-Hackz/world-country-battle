# Changelog

All notable changes to **String Circle — World Country Battle** are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned

- Inline Tailwind and Inter font so the APK renders identically offline.
- Adaptive launcher icon (`mipmap-anydpi-v26`) and themed monochrome icon.
- Landscape / tablet layout tuning for large arenas.
- Optional release-signed build via repository secrets.
- Local high-score / win-count history with `localStorage`.

## [1.0.0] — 2026-11-21

First public release. Playable in the browser and installable as an Android APK.

### Added

- **Battle engine** — 2 to 5 country balls bounce inside a circular arena; each ball owns a fan of strings radiating to the rim. A rival ball that touches a string cuts it, and a country is eliminated when its last string is gone. Last country standing wins.
- **Physics** — gravity, elastic ball-to-ball collisions, circle-wall reflection with anti-loop jitter, and speed regulation so no ball ever stalls. Three physics sub-steps per frame for stable collision resolution; simulation delta clamped to 40 ms.
- **195 sovereign countries** (ISO 3166-1 alpha-2) with live flag images and flag emoji fallback.
- **Country picker** with instant search across all 195 nations, assignable per slot.
- **Randomise** button for a fresh country lineup in one tap.
- **String count slider** — 1 to 80 strings per country (default 50).
- **Speed control** — 0.75×, 1.0×, 1.5×, 2.0×.
- **Synthesised audio** via the Web Audio API: string snap, wall bounce, elimination sweep and a four-note victory arpeggio. Mute toggle included.
- **Clean / record mode** that hides all UI chrome for screen recording.
- **Winner overlay** showing flag, country name, strings remaining and elapsed time, with Replay and Change Countries actions.
- **Android wrapper** — dependency-free `WebView` activity, immersive full-screen, portrait-locked, screen kept awake, back button handling, lifecycle-safe WebView teardown.
- **CI** — GitHub Actions workflow builds the debug APK on every push to `main` and publishes it to a GitHub Release on every `v*` tag.

### Known limitations

- Tailwind CSS and the Inter font load from CDNs, so a fully offline device gets a plain-looking but functional UI.
- Flags load from `flagcdn.com`; without internet the flag emoji fallback is shown.
- The published APK is debug-signed, which is fine for sideloading but not for Play Store distribution.
