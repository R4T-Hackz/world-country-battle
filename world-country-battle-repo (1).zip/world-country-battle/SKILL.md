---
name: string-circle
description: Build, run, tune and package "String Circle — World Country Battle", a single-file canvas game where 2–5 country balls battle inside a circular arena and cut each other's strings until one country is left. Use when working on this game's gameplay, physics, visuals, country data, sound, or its Android WebView APK wrapper.
version: 1.0.0
license: none (all rights reserved)
---

# String Circle — World Country Battle

A "skill" document for the game: what it is, how it is built, where every tunable
lives, and the safe recipes for changing it. Everything the player sees is in one
file — `index.html` — with no build step and no dependencies beyond two CDNs.

## 1. What the game is

- An arena is a circle drawn on a black canvas.
- Each of 2–5 countries is a coloured ball with its real flag, bouncing inside the arena.
- Every ball owns a **fan of strings**: straight lines from the arena's centre out to
  the rim, spread over that country's angular sector.
- Any ball that touches a *rival's* string cuts it permanently.
- When a country's last string is cut, that country is eliminated.
- The last country with strings remaining wins; the overlay shows flag, strings left
  and elapsed time.

Typical battle length: 25–45 seconds.

## 2. Files

| Path | Role |
| --- | --- |
| `index.html` | The whole game: markup, styles, country data, physics, rendering, audio |
| `android/` | Gradle project for the APK (plain `WebView`, no libraries) |
| `android/app/src/main/assets/index.html` | Copy of the game, refreshed by CI before every build |
| `.github/workflows/android.yml` | Builds the APK, publishes it on a `v*` tag |
| `README.md` / `CHANGELOG.md` | User-facing docs |

`index.html` is the single source of truth. Never edit the copy under
`android/app/src/main/assets/` by hand — CI overwrites it with `cp index.html ...`.

## 3. Running it

```bash
open index.html            # macOS
xdg-open index.html        # Linux
python3 -m http.server 8000  # or serve it, then visit localhost:8000
```

Build the APK:

```bash
cp index.html android/app/src/main/assets/index.html
cd android && gradle assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
```

Requires JDK 17 and Android SDK `compileSdk 34`, `minSdk 21`.

## 4. Where everything lives in `index.html`

| Area | Anchor |
| --- | --- |
| Arena, header, scoreboard, modals | `<body>`, ids `gameCanvas`, `scoreboard`, `setupModal`, `pickerModal`, `winnerOverlay` |
| Country list (195 entries, `[code, name]`) | `const WORLD_COUNTRIES = [` |
| Colour palette for slots | `const DEFAULT_PALETTE = [` |
| Flag loading and cache | `getFlagImage(code)` → `https://flagcdn.com/w160/<cc>.png` |
| Sound synthesis | `ensureAudio()`, `playSnapSound()`, `playBounceSound()`, `playEliminationSound()`, `playVictorySound()` |
| Game state | `const state = { countryCount, stringsPerCountry, speedMultipliers, speedIdx, slots, running, finished, ... }` |
| Arena geometry | `resizeCanvas()` — computes `cx`, `cy`, `arenaR`, `ballR`, DPR-capped at 2 |
| Battle setup | `initBattle(autoStart)` — sectors, string fans, spawn points, launch velocities |
| Physics | `stepPhysics(dt)` — 3 sub-steps: wall bounce, ball collisions, string cutting |
| Rendering | `drawFrame()` — background, strings, particles, balls, rim flashes |
| UI wiring | the block after `btnSpeed.textContent = ...` (setup modal, picker, controls) |

## 5. Tuning knobs

All values below are in `index.html`; changing them needs no other edits.

| What | Where | Default |
| --- | --- | --- |
| Countries per battle | `state.countryCount`, buttons `data-count="2..5"` | 3 |
| Strings per country | `state.stringsPerCountry`, slider `min=1 max=80` | 50 |
| Speed steps | `state.speedMultipliers` | `[0.75, 1.0, 1.5, 2.0]` |
| Ball launch speed | `baseSpeed = Math.max(175, arenaR * 1.15)` in `initBattle` | — |
| Gravity | `const gravity = arenaR * 0.32` in `stepPhysics` | — |
| Speed regulation target | `targetSpeed = Math.max(175, arenaR * 1.18)` | — |
| Sector fan width | `usableArc = arcSpan * 0.72` | 72% of sector |
| Ball size | `ballR = clamp(arenaR * 0.095, 13, 24)` in `resizeCanvas` | — |
| Spawn distance | `spawnDist = arenaR * 0.45` | 45% of radius |
| Grace period at start | `cutCooldown: 0.35` | 0.35 s |
| Simulation step cap | `Math.min(dt, 0.04)` in `stepPhysics` | 40 ms |
| Physics sub-steps | `const substeps = 3` | 3 |

Cut detection uses `distPointToSegment(px, py, x1, y1, x2, y2)`, which clamps `t` to
`0.95` so a ball sitting on the owner's centre can't delete an entire fan in one frame.
There is also a per-cut cooldown; keep it if you raise ball speed.

## 6. Recipes

### Add or replace a country

Countries are ISO codes; the flag and emoji derive automatically.

```js
["IN","India"],   // ← append or edit inside WORLD_COUNTRIES
```

Flag URL becomes `flagcdn.com/w160/in.png`; emoji is computed from the code with the
regional-indicator offset (`127397 + charCode`). Keep codes uppercase and 2 letters.

### Change slot colours

Edit `DEFAULT_PALETTE`. Slots take colours in order (`DEFAULT_PALETTE[i % 8]`), so keep
at least 5 entries to give every slot a distinct colour.

### Add a speed step

Append to `state.speedMultipliers`; the `btnSpeed` label and cycling logic read the
array length automatically.

### Add a sound

Follow the `playSnapSound()` shape: create oscillator → gain envelope →
`exponentialRampToValueAtTime(0.001, ...)` → `connect(audioCtx.destination)`. Guard
every sound with `if (isMuted || !audioCtx) return;` and call `ensureAudio()` from a
user gesture first, otherwise browsers keep the context suspended.

### Keep an offline-capable build

Two external requests exist: the Tailwind CDN and Google Fonts. To make the APK work
identically without internet, inline the compiled Tailwind CSS into a `<style>` block,
drop the `<script src="...tailwindcss...">` tag, and self-host Inter with
`@font-face`. Flag images already fall back to emoji when offline.

### Change app identity

- Name: `android/app/src/main/res/values/strings.xml` → `app_name`
- Package / applicationId: `android/app/build.gradle` → `namespace` and
  `applicationId`, plus the `package` line and folder path in `MainActivity.java`
- Version: `versionCode` / `versionName` in `android/app/build.gradle`; keep them in
  step with the git tag (`v1.0.1` ↔ `versionName "1.0.1"`)
- Icon: replace `android/app/src/main/res/mipmap-*/ic_launcher.png`
  (48/72/96/144/192 px)

## 7. Release procedure

```bash
git tag v1.0.1
git push origin v1.0.1
```

The workflow builds the debug APK and attaches
`StringCircle-WorldCountryBattle-1.0.1.apk` to the release. Pushes to `main` only
produce a workflow artifact, not a release. Always add a matching `CHANGELOG.md`
entry before tagging.

## 8. Gotchas

- `requestAnimationFrame` is throttled in background tabs; the `dt` clamp prevents the
  simulation from jumping when the player returns.
- `resizeCanvas()` rescales existing ball positions proportionally, so rotating or
  resizing mid-battle does not break the run — keep that rescale block if you touch
  geometry.
- `setSystemUiVisibility` is deprecated but is the only option without AndroidX; the
  wrapper intentionally avoids dependencies so CI builds stay fast.
- The WebView loads `file:///android_asset/index.html`; remote CDNs still load because
  the `INTERNET` permission is declared. Removing that permission breaks flags,
  fonts and Tailwind.
